Run: python download_model.py
Or copy your existing models/gesture_recognizer.task here and use --model models/gesture_recognizer.task
